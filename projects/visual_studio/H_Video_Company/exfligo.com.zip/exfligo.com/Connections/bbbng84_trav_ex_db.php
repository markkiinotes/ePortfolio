<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_bbbng84_trav_ex_db = "exfligo.myamyacf.com";
$database_bbbng84_trav_ex_db = "bbbng84_trav_ex_db";
$username_bbbng84_trav_ex_db = "bbbng84_mnotes";
$password_bbbng84_trav_ex_db = "Diamondz#@1";
$bbbng84_trav_ex_db = mysql_pconnect($hostname_bbbng84_trav_ex_db, $username_bbbng84_trav_ex_db, $password_bbbng84_trav_ex_db) or trigger_error(mysql_error(),E_USER_ERROR); 
?>