<?php 	require_once('cache/cache.php');
		require_once('admin/initialize.php');
		$page_title = 'Billing Information';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');
		?>
<main>
	<div class="container billing">
		<h1 class="mb-5" style="color: whitesmoke; text-align: center">Billing</h3>
		<form class="" id="register_form" name="register_form" method="post" action="">
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">First name</span>
  				</div>
  				<input type="text" class="form-control" name="first_name" id="first_name">
			</div>
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Last name</span>
  				</div>
				<input type="text" class="form-control" name="last_name" id="last_name">
			</div>		
		  <div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Street address</span>
  				</div>
  				<input type="text" class="form-control" name="address" id="address">
			</div>
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">City</span>
  				</div>
				<input type="text" class="form-control" name="city" id="city" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">State</span>
  				</div>
				<input type="text" class="form-control" name="state" id="state" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Zip</span>
  				</div>
				<input type="text" class="form-control" name="zip_code" id="zip_code" >
			</div>	
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Email</span>
  				</div>
				<input type="email" class="form-control" name="email" id="email" >
			</div>	
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Telephone</span>
  				</div>
				<input type="tel" class="form-control" name="phone" id="phone" >
			</div>		
			<button class="btn btn-primary" type="submit" name="submit" id="submit">Register</button>
		</form>
	</div>
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  require_once('cache/cache_footer.php');?>
