<?php 	include_once('cache/cache.php');
		include_once('admin/initialize.php');
		$page_title = 'Exfligo Car Rentals';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');
		include(INCLUDES_PATH . '/rental_car_search.php');
?>
<main>
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  include_once('cache/cache_footer.php');?>