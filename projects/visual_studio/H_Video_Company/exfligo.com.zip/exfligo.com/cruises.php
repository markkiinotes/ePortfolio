<?php 	include_once('cache/cache.php');
		include_once('admin/initialize.php');
		$page_title = 'Exfligo Cruises';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');
		include(INCLUDES_PATH . '/cruises_search.php');
?>
<main>

</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  include_once('cache/cache_footer.php');?>