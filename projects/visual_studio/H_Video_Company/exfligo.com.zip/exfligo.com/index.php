<?php 	require_once('cache/cache.php');
		require_once('admin/initialize.php');
		$page_title = 'Exfligo Home';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');
		include(INCLUDES_PATH . '/header_v2.php');?>
<main>
	<h4>Hot Deals</h4>	
 <div class="deals regular slider" name='hot_deals' id='hot_deals'>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top " src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
	 <div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
</div>

	<h4>Packages</h4>
 <div class="deals  regular slider" name='packages' id='packages' >
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top " src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
	 <div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
</div>
	
	<h4>Group Tours</h4>
<div class="deals regular slider" name='group_tours' id='group_tours' >
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
		<div class="card">
		  <img class="card-img-top" src="admin/images/bangkok1.jpg" alt="Card image cap">
		</div>
</div>
	
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  require_once('cache/cache_footer.php');?>
