<?php 	include_once('cache/cache.php');
		$page_title = 'Register';
		include('admin/includes/head.php');
		include('admin/includes/navbar.php');?>
<main>
	
	<div class="container register">
		<h3 class="mb-5" style="color: whitesmoke; text-align: center">Register</h3>
		<form class="" id="register_form" name="register_form" method="post" action="">
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Username</span>
  				</div>
  				<input type="text" class="form-control" name="username" id="username">
			</div>
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">First name</span>
  				</div>
				<input type="text" class="form-control" name="first_name" id="first_name">
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Last name</span>
  				</div>
				<input type="text" class="form-control" name="last_name" id="last_name">
			</div>		
		  <div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Street address</span>
  				</div>
  				<input type="text" class="form-control" name="address" id="address">
			</div>
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">City</span>
  				</div>
				<input type="text" class="form-control" name="city" id="city" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">State</span>
  				</div>
				<input type="text" class="form-control" name="state" id="state" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Zip</span>
  				</div>
				<input type="text" class="form-control" name="zip_code" id="zip_code" >
			</div>	
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Email</span>
  				</div>
				<input type="text" class="form-control" name="email" id="email" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Repeat Email</span>
  				</div>
				<input type="text" class="form-control" name="confirm_email" id="confirm_email" >
			</div>	
			<div class="input-group input-group-sm mb-3">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Password</span>
  				</div>
				<input type="text" class="form-control" name="password" id="password" >
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Repeat Password</span>
  				</div>
				<input type="text" class="form-control" name="confirm_password" id="confirm_password">
			</div>	
			<button class="btn btn-primary" type="submit" name="submit" id="submit">Register</button>
		</form>
	</div>
</main>
<?php include('admin/includes/footer.php');
	  include_once('cache/cache_footer.php');?>