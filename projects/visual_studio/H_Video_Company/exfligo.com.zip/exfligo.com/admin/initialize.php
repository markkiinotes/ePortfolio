<?php
	//Define CONSTANTS
	ini_set("include_path", '/home2/bbbng84/php:' . ini_get("include_path") );
	define("ROOT", '../' . __DIR__);
	define("ADMIN_PATH", __DIR__);
	define("INCLUDES_PATH", ADMIN_PATH .'/includes');
	define("SHARED_PATH", ADMIN_PATH . '/shared');
	define("AGENT_PATH", ROOT . '/agent');
	define("USER_PATH", ROOT . '/user');

	
	//require_once('functions.php');
	ini_set("SMTP","mail.exfligo.com" ); 
	ini_set('sendmail_from', 'admin@exfligo.com');
?>