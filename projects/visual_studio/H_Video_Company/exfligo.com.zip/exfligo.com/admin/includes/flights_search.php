<?php echo("
<header>	
   <div class='container search_box' id='search_box'>		
	<!-- BEGIN FLIGHT SEARCH FORM-->			
	
		<h1 class='mt-4 mb-3' style='text-align: center'>Flights</h1>
		
          <div class='tab-pane fade show active' role='tabpanel' aria-labelledby='pill_flights' id='flights_search_form'>
            <form name='flight_search' id='flight_search' method='post' action='#'>
              
                <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Flight from:</span>
  					</div>
				<input type='text' class='form-control' name='flight_from' id='flight_from'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Flight to:</span>
  					</div>
				<input type='text' class='form-control' name='flight_to' id='flight_to'>
				</div>		
             
			
				 <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Leaving Date:</span>
  					</div>
				<input type='date' class='form-control' name='leaving_date' id='leaving_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return Date:</span>
  					</div>
				<input type='date' class='form-control' name='return_date' id='return_date'>
				</div>		            
			
				
					<div class='input-group mb-4'>					
						<div class='input-group-prepend'>
    						<label class='input-group-text' for='travelers'>Travelers</label>
  						</div>
  					<select class='custom-select' id='travelers'>
						<option selected></option>
						<option value='1'>Adults</option>
						<option value='2'>Children</option>
						<option value='3'>Infants</option>
  					</select>
					
  						<div class='input-group-prepend'>
    						<label class='input-group-text' for='preferred_class'>Preferred Class</label>
  						</div>
  					<select class='custom-select' id='preferred_class'>
						<option selected>Choose Class</option>
						<option value='1'>Economy</option>
						<option value='2'>First Class</option>
						<option value='3'>Business Class</option>
  					</select>
					
					</div>								
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>					
              </form> 
          </div>
		 		
	   <!-- END FLIGHT SEARCH FORM-->
	
</div><!--END of search box container-->
	<img src='admin/images/Port_in_Kotor_on_the_background_of_the_mountain.jpg' alt='Mountains' width='66.8%' height='30%' class='img-fluid search_bckgrd'>
</header>");?>