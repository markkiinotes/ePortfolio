<?php echo("
	<!doctype html>
		<html>
			<head>");
		include('../admin/includes/google_tracking_exflygo.php');	
		echo  ("<meta charset='utf-8'>
				<meta http-equiv='X-UA-Compatible' content='IE=edge'>
				<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
				<title>ExFlyGo | ");
		echo($page_title);
		echo("</title>
				
				<link rel='stylesheet' href='../admin/bootstrap4.1.1/css/bootstrap.min.css'>
				
				<link href='../admin/jQueryAssets/jquery.ui.core.min.css' rel='stylesheet' type='text/css'>
				<link href='../admin/jQueryAssets/jquery.ui.theme.min.css' rel='stylesheet' type='text/css'>
				<link href='../admin/jQueryAssets/jquery.ui.tabs.min.css' rel='stylesheet' type='text/css'>
				<link href='../admin/open-iconic-master/font/css/open-iconic-bootstrap.css' type='text/css'/>
				<link href='../admin/css/main.css' rel='stylesheet'>
				<script src='../admin/jQueryAssets/jquery-1.11.1.min.js'></script>
				<script src='../admin/jQueryAssets/jquery.ui-1.10.4.tabs.min.js'></script>
					<script src='../jquery/jquery-3.3.1.js'></script>
					<script src='../jquery/jquery-migrate-1.4.1.js'></script>
					<script src='../jquery-ui-1.12.1/jquery-ui.min.js'></script>
					<script src='../jquery/jquery-migrate-3.0.0.js'></script>
				<script src='../admin/js/carousel.js' type='text/javascript'></script>
				<script src='../admin/js/main.js' type='text/javascript'></script>
			</head>
	<body>");
?>
