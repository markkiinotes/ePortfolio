<?php echo("
<header>	
   <div class='container search_box' id='search_box'>
   <!--Pills for trip search blocks-->
      <ul class='nav nav-pills mb-4' id='pills-tab' role='tablist'>
        <li class='nav-item'><a class='nav-link active' id='pill_flights' data-toggle='pill' role='tab' aria-controls='flights_search_form' aria-selected='true' href='#flights_search_form'>Flights</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_flight_hotel' data-toggle='pill' role='tab' aria-controls='flight_hotel_search_form' aria-selected='false' href='#flight_hotel_search_form'>Flight+Hotel</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_hotels' data-toggle='pill' role='tab' aria-controls='hotels_search_form' aria-selected='false' href='#hotels_search_form'>Hotels</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_cars' data-toggle='pill' role='tab' aria-controls='cars_search_form' aria-selected='false' href='#cars_search_form'>Cars</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_cruises' data-toggle='pill' role='tab' aria-controls='cruises_search_form' aria-selected='false' href='#cruises_search_form'>Cruises</a></li>
      </ul>

	  <!--Search Blocks-->
		<div class='tab-content'>
			
          <div class='tab-pane fade show active' role='tabpanel' aria-labelledby='pill_flights' id='flights_search_form'>
            <form name='flight_search' id='flight_search' method='post' action='#'>
              <div class='row'>
                <div class='col'>
					<label for='fly_to'>Flight to:</label>
                   <input type='text' class='form-control' placeholder='Fly to' id='fly_to' name='fly_to'>
                  </div>
                <div class='col'>
					<label for'fly_from'>Flight from:</label>
                  <input type='text' class='form-control' placeholder='Fly from' id='fly_from' name='fly_from'>
                  </div>
              </div>
			<div class='row'>
				<div class='col-lg-4' name='departure_day' id='departure_day'>
					<label for='departure_date'>Departure Date:</label>
					<input type='date' name='departure_date' id='departure_date' class='form-control' placeholder='Depature Date'/>					
				</div>	
				<div class='col-lg-4' name='return_day' id='return_day'>
					<label for='departure_date'>Return Date:</label>
					<input type='date' name='return_date' id='return_date' class='form-control' placeholder='Return Date'/>					
				</div>	
			</div>
				<div class='row'>
					<div class='col-lg-4'>
						<label for='num_of_travelers'>Number of Travelers:</label>
						<input type='text' name='num_of_travelers' id='num_of_travelers' class='form-control' placeholder='How many?'/>
					</div>
					<div class='col-lg-4'>
						<label for='class'>Class Preference:</label>
						<input type='text' name='class' id='class' class='form-control' placeholder='Class'/>
					</div>
				</div>
				
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>					
              </form> 
          </div>
		 		
	   
	   
	   
	   
	    <div class='tab-pane fade' aria-labelledby='pill_flight_hotel' id='flight_hotel_search_form' role='tabpanel'>
            <form name='flight_hotel_search' id='flight_hotel_search' method='post' action='#'>
                <div class='row'>
                <div class='col'>
					<label for='fly_to'>Flight to:</label>
                   <input type='text' class='form-control' placeholder='Fly to' id='fly_to' name='fly_to'>
                  </div>
                <div class='col'>
					<label for'fly_from'>Flight from:</label>
                  <input type='text' class='form-control' placeholder='Fly from' id='fly_from' name='fly_from'>
                  </div>
              </div>
			<div class='row'>
				<div class='col-lg-3' name='departure_day' id='departure_day'>
					<label for='departure_date'>Departure Date:</label>
					<input type='date' name='departure_date' id='departure_date' class='form-control' placeholder='Depature Date'/>					
				</div>	
				<div class='col-lg-3' name='return_day' id='return_day'>
					<label for='departure_date'>Return Date:</label>
					<input type='date' name='return_date' id='return_date' class='form-control' placeholder='Return Date'/>					
				</div>	
			</div>
				<div class='row'>
					<div class='col-lg-4'>
						<label for='num_of_travelers'>Number of Travelers:</label>
						<input type='text' name='num_of_travelers' id='num_of_travelers' class='form-control' placeholder='How many?'/>
					</div>
					<div class='col-lg-4'>
						<label for='num_of_travelers'>Rooms:</label>
						<input type='text' name='num_of_travelers' id='num_of_travelers' class='form-control' placeholder='How many?'/>
					</div>
				</div>
				<div class='row'>
					<div class='col-lg-4'>
						<label for='class'>Class Preference:</label>
						<input type='text' name='class' id='class' class='form-control' placeholder='Class'/>
					</div>
				</div>
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>
              </form> 
          </div>
		
	
	
	
	<div class='tab-pane fade' aria-labelledby='pill_hotels' id='hotels_search_form' role='tabpanel'>
            <form name='hotels_search' id='hotel_search' method='post' action='#'>
              <div class='row'>
                <div class='col-lg-10'>
					<label for='destination'>Destination:</label>
                  <input type='text' class='form-control' placeholder='Destination' id='destination' name='destination'>
                 </div>               
              </div>
			<div class='row'>				
				<div class='col-lg-4'>
					<label for='hotel_check_in'>Check-in:</label>
					<input type='date' name='hotel_check_in' id='hotel_check_in' class='form-control' placeholder='hotel_check_in'/>					
				</div>	
				<div class='col-lg-4'>			
					<label for='hotel_check_out'>Check-out:</label>
					<input type='date' name='hotel_check_out' id='hotel_check_out' class='form-control' placeholder='hotel_check_out'/>
				</div>	
			</div>
				<div class='row'>
					<div class='col-lg-4'>
						<label for='travelers'>Travelers:</label>
						<input type='text' name='travelers' id='travelers' class='form-control' placeholder='Travelers'/>
					</div>
					<div class='col-lg-4'>
						<label for='travelers'>Rooms:</label>
						<input type='text' name='rooms' id='rooms' class='form-control' placeholder='Rooms'/>
					</div>
				</div>
				
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
	  	
			
			<div class='tab-pane fade' aria-labelledby='pill_cars' id='cars_search_form' role='tabpanel'>
            <form name='cars_search' id='cars_search' method='post' action='#'>
              <div class='row'>
                <div class='col'>
					<label for='pickup_location'>Pick-up:</label>
                  <input type='text' class='form-control' placeholder='Pickup location' id='pickup_location' name='pickup_location'>
                 </div>   
				  <div class='col'>
					<label for='pickup_location'>Drop-off:</label>
                  <input type='text' class='form-control' placeholder='Drop-off location' id='dropoff_location' name='dropoff_location'>
                 </div>   
              </div>
			<div class='row'>				
				<div class='col'>
					<label for='pickup_date'>Pick-up Date:</label>
					<input type='date' name='pickup_date' id='pickup_date' class='form-control' placeholder='Pick-up Date'/>			
				</div>	
				<div class='col' name='departure' id='departure'>		
					<label for='dropoff_date'>Drop-off Date:</label>
					<input type='date' name='dropoff_date' id='dropoff_date' class='form-control' placeholder='Drop-off Date'/>			
				</div>	
			</div>
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
			
			<div class='tab-pane fade' aria-labelledby='pill_cruises' id='cruises_search_form' role='tabpanel'>
            <form name='cruises_search' id='cruises_search' method='post' action='#'>
              <div class='row'>
                <div class='col-lg-10'>
					<label for='destination'>Destination:</label>
                  <input type='text' class='form-control' placeholder='Destination' id='destination' name='destination'>
                 </div>               
              </div>
			<div class='row'>				
				<div class='col-lg-5' name='departure' id='departure'>
					<label for='leaving'>Departure:</label>
					<input type='text' name='leaving' id='leaving' class='form-control' placeholder='Leaving'/>					
				</div>					
			</div>
				<div class='row'>
					<div class='col-lg-4'>
						<label for='travelers'>Travelers:</label>
						<input type='text' name='travelers' id='travelers' class='form-control' placeholder='Travelers'/>
					</div>
				</div>
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
	</div>  <!--END of contents of search box-->
</div><!--END of search box container-->
	<img src='../admin/images/Port_in_Kotor_on_the_background_of_the_mountain.jpg' alt='Mountains' width='66.8%' height='30%' class='img-fluid search_bckgrd'>
</header>");?>