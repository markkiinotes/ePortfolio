<?php echo("
<header>	
   <div class='container search_box' id='search_box'>
   <h1 class='mt-4 mb-3' style='text-align: center'>Packages</h1>
	<!-- BEGIN HOTELS SEARCH FORM-->
	<div class='tab-pane fade show active' aria-labelledby='pill_packages' id='packages_search_form' role='tabpanel'>
            <form name='packages_search' id='packages_search' method='post' action='#'>
             	<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<span class='input-group-text'>Destination</span>
  					</div>
  						<input type='text' class='form-control' name='destination' id='destination'>					
				</div>
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Check-in Date:</span>
  					</div>
						<input type='date' class='form-control' name='check_in' id='check_in'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Check-out Date:</span>
  					</div>
						<input type='date' class='form-control' name='check_out' id='check_out'>
				</div>	
				
				<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<label class='input-group-text' for='travelers'>Travelers</label>
  					</div>
  					<select class='custom-select' id='travelers'>
						<option selected></option>
						<option value='1'>Adults</option>
						<option value='2'>Children</option>
						<option value='3'>Infants</option>
  					</select>
					
  					<div class='input-group-prepend'>
    					<label class='input-group-text' for='preferred_class'>Rooms:</label>
  					</div>
  					<select class='custom-select' id='num_of_rooms'>
						<option selected></option>
						<option value='1'>1</option>
						<option value='2'>2</option>
						<option value='3'>3</option>
  					</select>					
					</div>	
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
	  	<!-- END HOTELS SEARCH FORM-->

</div><!--END of search box container-->
	<img src='admin/images/Port_in_Kotor_on_the_background_of_the_mountain.jpg' alt='Mountains' width='66.8%' height='30%' class='img-fluid search_bckgrd'>
</header>");?>