<?php 
	echo("
	 <!--USER Navigation Header-->
  <nav class='navbar navbar-expand-lg'>
   
		 <!--Left navbar logo with collapse-->		  
  			<a class='navbar-brand' href='index.php'>Exfligo</a>
			<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarContent' aria-controls='navbarContent' aria-expanded='false' aria-label='Toggle navigation'>
    			<span class='navbar-toggler-icon'></span>
  			</button>
			
		  <div class='collapse navbar-collapse navbar_center' id='navbarContent'>
	 	 <!--Center navbar menu links to search pages-->		  
			  <ul class='navbar-nav mr-auto'>
			  	<li class='nav-item active'><a class='nav-link' href='#'>Flights <span class='sr-only'>(current)</span></a></li>
  			  	<li class='nav-item'><a class='nav-link' href='#'>Hotels</a></li>
				<li class='nav-item'><a class='nav-link' href='#'>Cars</a></li>
  			  	<li class='nav-item'><a class='nav-link' href='#'>Packages</a></li>
  			  	<li class='nav-item'><a class='nav-link' href='#'>Cruises</a></li>
  			  	<li class='nav-item dropdown'>
					<a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Extras</a>
					<div class='dropdown-menu' aria-labelledby='navbarDropdown'>
						<a class='dropdown-item' href='#'>Extra 1</a>
					  	<a class='dropdown-item' href='#'>Extra 2</a>
					  	<a class='dropdown-item' href='#'>Extra 3</a>
					  	<a class='dropdown-item' href='#'>Extra 4</a>
					</div>
				  </li>
			  </ul>
	  </div>
		  <div class='account'>
		    <!--User account menu-->		 
		  	  <ul class='nav navbar-nav navbar-right col-xl-11'>				  
				<li class='nav-item dropdown'>
					<button class='btn btn-primary dropdown-toggle' data-toggle='dropdown'>				  
					 <span class='oi oi-person'></span><b style='font-size: 12pt'>My Account</b>
	 		  		</button>
				  <div class='dropdown-menu' aria-labelledby='navbarDropdown'>
					  <a class='dropdown-item' href='#'>Profile</a>
					  <a class='dropdown-item' href='#'>My Reservations</a>
					  <a class='dropdown-item' href='#'>My Searches</a>
					  <a class='dropdown-item' href='#'>History</a>
					  <a class='dropdown-item' href='#'><span class='oi oi-account-logout'>Logout</span></a>
				  </div>
				  </li>
				</ul>				
			</div>  
  </nav><!--END header Navigation-->	
	");
?>