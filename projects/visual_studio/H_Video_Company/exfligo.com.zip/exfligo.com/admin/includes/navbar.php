<?php 
	echo("
	 <!--Navigation Header-->
  <nav class='navbar navbar-expand-lg'>
   
		 <!--Left navbar logo with collapse-->		  
  			<a class='navbar-brand' href='index.php'>Exfligo</a>		
			<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarContent' aria-controls='navbarContent' aria-expanded='false' aria-label='Toggle navigation'>
    			<span class='navbar-toggler-icon'></span>
  			</button>
			
		  <div class='collapse navbar-collapse navbar_center' id='navbarContent'>
	 	 <!--Center navbar menu links to search pages-->		  
			  <ul class='navbar-nav mr-auto'>
			  	<li class='nav-item active'><a class='nav-link' href='flights.php'>Flights <span class='sr-only'>(current)</span></a></li>
  			  	<li class='nav-item'><a class='nav-link' href='hotels.php'>Hotels</a></li>
				<li class='nav-item'><a class='nav-link' href='rental_cars.php'>Cars</a></li>
  			  	<li class='nav-item'><a class='nav-link' href='packages.php'>Packages</a></li>
  			  	<li class='nav-item'><a class='nav-link' href='cruises.php'>Cruises</a></li>
  			  	<li class='nav-item dropdown'>
					<a class='nav-link dropdown-toggle' href='#' id='navbarDropdown' role='button' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>Extras</a>
					<div class='dropdown-menu' aria-labelledby='navbarDropdown'>
						<a class='dropdown-item' href='#'>Extra 1</a>
					  	<a class='dropdown-item' href='#'>Extra 2</a>
					  	<a class='dropdown-item' href='#'>Extra 3</a>
					  	<a class='dropdown-item' href='#'>Extra 4</a>
					</div>
				  </li>
			  </ul>
	  </div>
		  <div class='account'>
		    <!--User account Sign-in menu-->		 				
					<button href='#' class='btn btn-primary' data-toggle='modal' data-target='#loginModal'>				  
					 <span class='oi oi-person'></span><b style='font-size: 12pt'>My Account</b>
	 		  		</button>
							
			</div>  
  </nav><!--END header Navigation-->	
	");
?>