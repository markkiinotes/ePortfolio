<?php echo("
<header>	
   <div class='container search_box' id='search_box'>
  <h1 class='mt-4 mb-3' style='text-align: center'>Car Rentals</h1>
	<!-- BEGIN FLIGHT SEARCH FORM-->			
         <!-- BEGIN CARS SEARCH FORM-->	
		<div class='tab-pane fade show active' aria-labelledby='pill_cars' id='cars_search_form' role='tabpanel'>
            <form name='cars_search' id='cars_search' method='post' action='#'>
              <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up location:</span>
  					</div>
						<input type='text' class='form-control' name='pick_up_location' id='pick_up_location'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Drop-off location:</span>
  					</div>
						<input type='text' class='form-control' name='drop_off_location' id='drop_off_location'>
				</div>	
				
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up Date:</span>
  					</div>
						<input type='date' class='form-control' name='pick_up_date' id='pick_up_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up time:</span>
  					</div>
						<input type='time' class='form-control' name='pick_up_time' id='pick_up_time'>					
				</div>	
				
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return date:</span>
  					</div>
						<input type='date' class='form-control' name='return_date' id='return_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return time:</span>
  					</div>
						<input type='time' class='form-control' name='return_time' id='return_time'>
				</div>	
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
			<!-- END CARS SEARCH FORM-->
</div><!--END of search box container-->
	<img src='admin/images/Port_in_Kotor_on_the_background_of_the_mountain.jpg' alt='Mountains' width='66.8%' height='30%' class='img-fluid search_bckgrd'>
</header>");?>