<?php 
	require_once('admin/initialize.php');
	$title = $page_title  ?: 'Exfligo Page';
echo("
<!doctype html>
	<html>
		<head>");
		include_once(INCLUDES_PATH . '/google_tracking_exflygo.php');
		include_once(INCLUDES_PATH . '/google_adsense.php');		
		echo  ("<meta charset='utf-8'>
				<meta http-equiv='X-UA-Compatible' content='IE=edge'>
				<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
				<title>ExFligo | ");
		echo($title);
		echo("</title>				
				<link rel='stylesheet' href='admin/bootstrap4.1.1/css/bootstrap.min.css'>				
				<link href='admin/jQueryAssets/jquery.ui.core.min.css' rel='stylesheet' type='text/css'>
				<link href='admin/jQueryAssets/jquery.ui.theme.min.css' rel='stylesheet' type='text/css'>
				<link href='admin/jQueryAssets/jquery.ui.tabs.min.css' rel='stylesheet' type='text/css'>
				<link href='admin/open-iconic-master/font/css/open-iconic-bootstrap.css' type='text/css'/>
				<link href='admin/open-iconic-master/font/css/open-iconic.css' rel='stylesheet' />		
				
				<link rel='stylesheet' type='text/css' href='admin/slick-master/slick/slick.css'/>

				<link rel='stylesheet' type='text/css' href='admin/slick-master/slick/slick-theme.css'/>	
				<link href='admin/css/main.css' rel='stylesheet'/>
			</head>
	<body>");
?>
