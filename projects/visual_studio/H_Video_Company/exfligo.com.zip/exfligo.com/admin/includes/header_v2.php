<?php echo("
<header>	
   <div class='container search_box' id='search_box'>
   
   <!--Pills for trip search blocks-->
   
      <ul class='nav nav-pills mb-4' id='pills-tab' role='tablist'>
        <li class='nav-item'><a class='nav-link active' id='pill_flights' data-toggle='pill' role='tab' aria-controls='flights_search_form' aria-selected='true' href='#flights_search_form'>Flights</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_flight_hotel' data-toggle='pill' role='tab' aria-controls='flight_hotel_search_form' aria-selected='false' href='#flight_hotel_search_form'>Flight+Hotel</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_hotels' data-toggle='pill' role='tab' aria-controls='hotels_search_form' aria-selected='false' href='#hotels_search_form'>Hotels</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_cars' data-toggle='pill' role='tab' aria-controls='cars_search_form' aria-selected='false' href='#cars_search_form'>Cars</a></li>
        <li class='nav-item'><a class='nav-link' id='pill_cruises' data-toggle='pill' role='tab' aria-controls='cruises_search_form' aria-selected='false' href='#cruises_search_form'>Cruises</a></li>
      </ul>

	<!--Search Blocks-->
	<div class='tab-content'>		
		
	<!-- BEGIN FLIGHT SEARCH FORM-->			
          <div class='tab-pane fade show active' role='tabpanel' aria-labelledby='pill_flights' id='flights_search_form'>
            <form name='flight_search' id='flight_search' method='post' action='#'>
              
                <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Flight from:</span>
  					</div>
				<input type='text' class='form-control' name='flight_from' id='flight_from'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Flight to:</span>
  					</div>
				<input type='text' class='form-control' name='flight_to' id='flight_to'>
				</div>		
             
			
				 <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Leaving Date:</span>
  					</div>
				<input type='date' class='form-control' name='leaving_date' id='leaving_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return Date:</span>
  					</div>
				<input type='date' class='form-control' name='return_date' id='return_date'>
				</div>		            
			
				
					<div class='input-group mb-4'>					
						<div class='input-group-prepend'>
    						<label class='input-group-text' for='travelers'>Travelers</label>
  						</div>
  					<select class='custom-select' id='travelers'>
						<option selected></option>
						<option value='1'>Adults</option>
						<option value='2'>Children</option>
						<option value='3'>Infants</option>
  					</select>
					
  						<div class='input-group-prepend'>
    						<label class='input-group-text' for='preferred_class'>Preferred Class</label>
  						</div>
  					<select class='custom-select' id='preferred_class'>
						<option selected>Choose Class</option>
						<option value='1'>Economy</option>
						<option value='2'>First Class</option>
						<option value='3'>Business Class</option>
  					</select>
					
					</div>								
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>					
              </form> 
          </div>
		 		
	   <!-- END FLIGHT SEARCH FORM-->
	   
	   
	   <!-- BEGIN FLIGHT+HOTEL SEARCH FORM-->
	    <div class='tab-pane fade' aria-labelledby='pill_flight_hotel' id='flight_hotel_search_form' role='tabpanel'>
            <form name='flight_hotel_search' id='flight_hotel_search' method='post' action='#'>
                <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Flight from:</span>
  					</div>
						<input type='text' class='form-control' name='flight_from' id='flight_from'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Flight to:</span>
  					</div>
				<input type='text' class='form-control' name='flight_to' id='flight_to'>
				</div>		
             	
				 <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Leaving Date:</span>
  					</div>
				<input type='date' class='form-control' name='leaving_date' id='leaving_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return Date:</span>
  					</div>
				<input type='date' class='form-control' name='return_date' id='return_date'>
				</div>					
				<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<label class='input-group-text' for='travelers'>Travelers</label>
  					</div>
  					<select class='custom-select' id='travelers'>
						<option selected></option>
						<option value='1'>Adults</option>
						<option value='2'>Children</option>
						<option value='3'>Infants</option>
  					</select>
					
  						<div class='input-group-prepend'>
    						<label class='input-group-text' for='preferred_class'>Rooms:</label>
  						</div>
  					<select class='custom-select' id='num_of_rooms'>
						<option selected></option>
						<option value='1'>1</option>
						<option value='2'>2</option>
						<option value='3'>3</option>
  					</select>					
				</div>
				<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<label class='input-group-text' for='preferred_class'>Preferred Class</label>
  					</div>
  					<select class='custom-select' id='preferred_class'>
						<option selected>Choose Class</option>
						<option value='1'>Economy</option>
						<option value='2'>First Class</option>
						<option value='3'>Business Class</option>
  					</select>
					
				</div>
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>
              </form> 
          </div>
	<!-- END FLIGHT+HOTEL SEARCH FORM-->	
	
	
	<!-- BEGIN HOTELS SEARCH FORM-->
	<div class='tab-pane fade' aria-labelledby='pill_hotels' id='hotels_search_form' role='tabpanel'>
            <form name='hotels_search' id='hotel_search' method='post' action='#'>
             	<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<span class='input-group-text'>Destination</span>
  					</div>
  						<input type='text' class='form-control' name='destination' id='destination'>					
				</div>
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Check-in Date:</span>
  					</div>
						<input type='date' class='form-control' name='check_in' id='check_in'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Check-out Date:</span>
  					</div>
						<input type='date' class='form-control' name='check_out' id='check_out'>
				</div>	
				
				<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<label class='input-group-text' for='travelers'>Travelers</label>
  					</div>
  					<select class='custom-select' id='travelers'>
						<option selected></option>
						<option value='1'>Adults</option>
						<option value='2'>Children</option>
						<option value='3'>Infants</option>
  					</select>
					
  					<div class='input-group-prepend'>
    					<label class='input-group-text' for='preferred_class'>Rooms:</label>
  					</div>
  					<select class='custom-select' id='num_of_rooms'>
						<option selected></option>
						<option value='1'>1</option>
						<option value='2'>2</option>
						<option value='3'>3</option>
  					</select>					
					</div>	
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
	  	<!-- END HOTELS SEARCH FORM-->
		
		
		<!-- BEGIN CARS SEARCH FORM-->	
		<div class='tab-pane fade' aria-labelledby='pill_cars' id='cars_search_form' role='tabpanel'>
            <form name='cars_search' id='cars_search' method='post' action='#'>
              <div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up location:</span>
  					</div>
						<input type='text' class='form-control' name='pick_up_location' id='pick_up_location'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Drop-off location:</span>
  					</div>
						<input type='text' class='form-control' name='drop_off_location' id='drop_off_location'>
				</div>	
				
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up Date:</span>
  					</div>
						<input type='date' class='form-control' name='pick_up_date' id='pick_up_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text'>Pick-up time:</span>
  					</div>
						<input type='time' class='form-control' name='pick_up_time' id='pick_up_time'>					
				</div>	
				
				<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return date:</span>
  					</div>
						<input type='date' class='form-control' name='return_date' id='return_date'>
					<div class='input-group-prepend'>
    					<span class='input-group-text' id=''>Return time:</span>
  					</div>
						<input type='time' class='form-control' name='return_time' id='return_time'>
				</div>	
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form> 
          </div>
			<!-- END CARS SEARCH FORM-->
			
			<!-- BEGIN CRUISES SEARCH FORM-->
		<div class='tab-pane fade' aria-labelledby='pill_cruises' id='cruises_search_form' role='tabpanel'>
            <form name='cruises_search' id='cruises_search' method='post' action='#'>
               <div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<span class='input-group-text'>Destination</span>
  					</div>
  						<input type='text' class='form-control' name='destination' id='destination'>					
				</div>
			 	<div class='input-group mb-4'>
  					<div class='input-group-prepend'>
    					<span class='input-group-text'>Leaving Date:</span>
  					</div>
						<input type='date' class='form-control' name='leaving_date' id='leaving_date'>
				</div>
				<div class='input-group mb-4'>					
					<div class='input-group-prepend'>
    					<label class='input-group-text' for='travelers'>Travelers</label>
  					</div>
						<select class='custom-select' id='travelers'>
							<option selected></option>
							<option value='1'>Adults</option>
							<option value='2'>Children</option>
							<option value='3'>Infants</option>
						</select>
				</div>			
					<button type='button' id='search_button' class='btn btn-primary'>Search</button>				
              </form>
		</div><!-- END CRUISES SEARCH FORM-->
	</div>  <!--END of contents of search box-->
</div><!--END of search box container-->
	<img src='admin/images/Port_in_Kotor_on_the_background_of_the_mountain.jpg' alt='Mountains' width='66.8%' height='30%' class='img-fluid search_bckgrd'>
</header>");?>