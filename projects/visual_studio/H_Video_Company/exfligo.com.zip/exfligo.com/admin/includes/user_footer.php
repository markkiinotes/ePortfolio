<?php
	echo("
		<footer class='footer_container' id='footer_container'>
			<div class='eco_deals col-lg-2'>
				<h5>Economy Deals</h5>
					<ul>
						<li><a href='#'>Under $299</a></li>
						<li><a href='#'>Under $399</a></li>
						<li><a href='#'>Under $499</a></li>
						<li><a href='#'>Under $699</a></li>
						<li><a href='#'>Under $899</a></li>
					</ul>
			</div>
			<div class='disney col-lg-2'>
				<h5>Disney Vacations</h5>
					<ul>
						<li><a href='#'>Disney World Resort</a></li>
						<li><a href='#'>Disney Land</a></li>
						<li><a href='#'>Disney Cruises</a></li>
					</ul>
			</div>	
			<div class='world_cruises col-lg-2'>
				<h5>Cruise the World</h5>
					<ul>
						<li><a href='#'>Princess Cruise Line</a></li>
						<li><a href='#'>Oceania Cruise Line</a></li>
						<li><a href='#'>Regent 7 Seas Cruises</a></li>
						<li><a href='#'>Cunard Lines</a></li>
					</ul>
			</div>
			<div class='about col-lg-1'>
				<h5>About </h5>
					<ul>
						<li><a href='#'>ExFlyGo</a></li>
						<li><a href='#'>Policies</a></li>
						<li><a href='#'>Contact ExFlyGo</a></li>
						<li><a href='#'>Cookies</a></li>
					</ul>
			</div>
			<div class='follow col-lg-3'>
				<h5>Follow</h5>
					 <ul>
						<li><a href='#'><img src='../admin/images/facebook.png' alt='Facebook' width='31' height='31'></a></li>
						<li><a href='#'><img src='../admin/images/twitter.png' alt='Twitter' width='31' height='31'></a></li>
						<li><a href='#'><img src='../admin/images/instagram.png' alt='Instagram' width='31' height='31'></a></li>
						<li><a href='#'><img src='../admin/images/linkedin.png' alt='LinkedIn' width='31' height='31'></a></li>
						<li><a href='#'><img src='../admin/images/pintrest.png' alt='Pintrest' width='31' height='31'></a></li>
					 </ul>
			  <p class='copyright'> &copy; ");
			echo(date('Y'));
		    echo(" ExFlyGo, LLC. All rights reserved.</p>
			</div>
		</footer>
	<script src='../admin/js/jquery-3.2.1.min.js'></script>
	<script src='../admin/js/popper.min.js'></script>
	<script src='../admin/bootstrap4.1.1/js/bootstrap.min.js'></script>
</body>
</html>");?>