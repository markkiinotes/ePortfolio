<?php
	echo ("
	<div class='modal' role='dialog' id='loginModal' tabindex='-1'>
		<div class='modal-dialog modal-sm' role='document'>
			<div class='modal-content'>
					<div class='modal-header'>
						<h5 class='modal-title' id='loginModalLabel'>Login</h5>
						<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
          					<span aria-hidden='true'>&times;</span>
        				</button>
					</div>					
					<div class='modal-body'>
					<form id='loginForm' action='../admin/shared/php/check_user_creditials.php' method='post'>
						<div class='form-group' id='login_email_form_group'>
							<label class='control-label' for='login_email'>Email</label>
							<input  aria-describedby='emailHelp' placeholder='Enter email' type='email' class='form-control' id='login_email'>
							<small id='emailHelp' class='form-text text-muted'>We'll never share your email with anyone else.</small>
							<p id='error_email'></p>
						</div>
						<div class='form-group' id='login_p_word_form_group'>
							<label class='control-label' for='login_p_word'>Password</label>
							<input  placeholder='Password' type='password' class='form-control' id='login_p_word'>
							<p id='error_p_word'></p>
						</div>
						 <div class='form-check'>
							<input type='checkbox' class='form-check-input' id='remember_me'>
							<label class='form-check-label' for='remember_me'>Remember me</label>
						 </div>							
<br/>
						<small>I don't an account? I want to <a href='register.php'>Sign Up</a>!</small>
<br/>
						<small>Forgot your <a href='forgot_password.php'>password</a>?</small>						
					</div>
					<div class='modal-footer'>
						<button type='button' class='btn btn-default' data-dismiss='modal'>Cancel</button>
						<button type='submit' name='submit' id='submit' class='btn btn-primary'>Login</button>
					</div>
				</form>
			</div>		
			
		</div>	
	</div>");
?>