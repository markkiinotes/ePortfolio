/*
*	PROGRAM: Carousel Modification
*	AUTHOR:	 George M. Harrison Jr. (ID:0189534)
*	PURPOSE: Swaps images in a carousel and add animation effects to transitions.
*	DATE:    Feb. 19, 2018
*/
$(document).ready(function() {
	"use strict";
	var slider = $("#image_list");                     // slider = ul element
	var leftProperty, newleftProperty;
		
	// the click event handler for the right button						
	$("#right_button").click(function() { 
		// get value of current left property
		leftProperty = parseInt(slider.css("left"));
		// determine new value of left property
		if (leftProperty - 300 <= -900) {
			newLeftProperty = 0; }
		else {
			newLeftProperty = leftProperty - 300; }
		// use the animate function to change the left property
		slider.animate( {left: newLeftProperty}, 1000);
	});  // end click
	
	// the click event handler for the left button
	$("#left_button").click(function() {
		// get value of current right property
		leftProperty = parseInt(slider.css("left"));
		
		// determine new value of left property
		if (leftProperty < 0) {
			newLeftProperty = leftProperty + 300;
		}
		else {
			newLeftProperty = 0;
		}
		
		// use the animate function to change the left property
		slider.animate( {left: newLeftProperty}, 1000);		
	});  // end click	
	
		//runs a function on all a elements in the image list
	$("#image_list a").each(function(){
		var swapImage = new Image();
		swapImage.src = $(this).attr("href");
	});	
		//this function retrieves the URL from the clicked image
		//and sets the display image equal to it value.
	$("#image_list a").click(function(evt){
		
		var imageURL = $(this).attr("href");		//gets URL from clicked image
		$("#image").attr("src", imageURL);			//sets the Display image.
		$("#image").animate({opacity:0, left:"-=205"},1000,function(){
		$("#image").animate({opacity:1, right:"-=205"},1000);});
		evt.preventDefault();
		
		
	});//end of click event
});