$(document).on( 'ready', function(){
	"use strict";

	$('.deals').slick({
	  arrows: true,
	  centerMode: true,
	  centerPadding: '60px',
	  slidesToShow: 5,
	  slidesToScroll: 1,
	  lazyLoad: 'ondemand',
  	  responsive: [
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 3
      }
    },
    {
      breakpoint: 480,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 1
      }
    }
  ]
});
	
// On swipe event
$('.deals').on('swipe', function(event, slick, direction){
  console.log(direction);
  // left
});

// On edge hit
$('.deals').on('edge', function(event, slick, direction){
  console.log('edge was hit');
});

// On before slide change
$('.deals').on('beforeChange', function(event, slick, currentSlide, nextSlide){
  console.log(nextSlide);
});
var w = $(window).width();
 $('.deals').css('width', w);


});//END OF THE READY FUNCTION