<?php 	include_once('cache/cache.php');
		include_once('admin/initialize.php');
		$page_title = 'Exflygo';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');?>
<main>

<div></div>
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  include_once('cache/cache_footer.php');?>
