<?php
// Number of seconds a page should remain cached for
$cache_expires = 3600;

// Path to the cache folder
$cache_folder = "/exfligo.com/cache/";

// Checks whether the page has been cached or not
function is_cached($file) {
	global $cache_folder, $cache_expires;
	$cachefile = $cache_folder . $file;
	$cachefile_created = (file_exists($cachefile)) ? @filemtime($cachefile) : 0;
	return ((time() - $cache_expires) < $cachefile_created);
}

// Reads from a cached file
function read_cache($file) {
	global $cache_folder;
	$cachefile = $cache_folder . $file;
	return file_get_contents($cachefile);
}

// Writes to a cached file
function write_cache($file, $out) {
	global $cache_folder;
	$cachefile = $cache_folder . $file;
	$fp = fopen($cachefile, 'w');
	fwrite($fp, $out);
	fclose($fp);
}

// first work out the cached filename
$cache_file = md5($_SERVER['REQUEST_URI']) . ".php";

// Check if it has already been cached and not expired
// If true then we output the cached file contents and finish
if (is_cached($cache_file)) {
	echo read_cache($cache_file);
	exit();
}

// Ok so the page needs to be cached
// Turn on output buffering
ob_start();
//Include cache.php on the first line before you do anything else. This is because if the page is cached we don't want it to do anything else other than output the cache to the page. If you are still including other files or connecting to databases before checking for the cache you are putting additional load on the server, making this exercise pointless.

//Finally create a file called cache_footer.php which contains the following code:

