<?php 	require_once('cache/cache.php');
		require_once('admin/initialize.php');
		$page_title = 'Billing Information';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');
		?>
<main>
	<div class="container credit_card">
		<h3 class="mb-5" style="color: whitesmoke; text-align: center">Payment Information</h3>
		
		<form class="" id="register_form" name="register_form" method="post" action="">
			<div class="input-group input-group-sm mb-5 col-xl-7 offset-xl-2">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Card Type</span>
					
  				</div>
  				<select class="form-control" name="name_on_card" id="name_on_card">
					<option selected></option>
					<option>VISA</option>
					<option>MASTERCARD</option>
					<option>AMEX</option>
					<option>PAYPAL</option>
					</select>
			</div>
			
			<div class="input-group input-group-sm mb-3 col-xl-11">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Name of Cardholder</span>
  				</div>
  				<input type="text" class="form-control" name="name_on_card" id="name_on_card">
			</div>
					
		  <div class="input-group input-group-sm mb-3 col-xl-11">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="inputGroup-sizing-sm">Number on Card</span>
  				</div>
  				<input type="number" class="form-control" name="card_num" id="card_nem">
			</div>
			<div class="input-group input-group-sm mb-3 col-xl-11">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Exp Date</span>
  				</div>
				<input type="month" class="form-control" name="city" id="city" >
				
				<div class="input-group-prepend">
    				<span class="input-group-text" id="">Zip Code</span>
  				</div>
				<input type="text" class="form-control" name="zip_code" id="zip_code" >
			</div>	
			<div class="input-group input-group-sm mb-3 col-xl-4">
  				<div class="input-group-prepend">
    				<span class="input-group-text" id="">CVC</span>
  				</div>
				<input type="text" class="form-control" name="cvc" id="cvc" >			
			</div>	
			
			<button class="btn btn-primary" type="submit" name="submit" id="submit">Register</button>
		</form>
	</div>
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  require_once('cache/cache_footer.php');?>
