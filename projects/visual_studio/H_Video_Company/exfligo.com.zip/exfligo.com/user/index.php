<?php 	include('../cache/cache.php');
		$page_title = 'Exflygo Home';
		include('../admin/includes/user_head.php');
		include('../admin/includes/user_navbar.php');
		include('../admin/includes/user_header.php');?>
	

<?php include('../admin/includes/user_footer.php');
	  include('../cache/cache_footer.php');?>
