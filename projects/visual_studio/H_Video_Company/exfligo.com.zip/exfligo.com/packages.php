<?php 	include_once('cache/cache.php');
		include_once('admin/initialize.php');
		$page_title = 'Exfligo Packages';
		include(INCLUDES_PATH . '/head.php');
		include(INCLUDES_PATH . '/navbar.php');?>
<main>
	<?php include(INCLUDES_PATH . '/package_search.php');?>
</main>
<?php include(INCLUDES_PATH . '/footer.php');
	  include_once('cache/cache_footer.php');?>